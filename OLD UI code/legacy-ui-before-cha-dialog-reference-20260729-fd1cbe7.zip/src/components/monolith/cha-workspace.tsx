"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  AlertTriangle,
  BarChart3,
  BriefcaseBusiness,
  Building2,
  CheckSquare,
  CreditCard,
  FileCog,
  Gauge,
  LoaderCircle,
  Settings2,
  UserPlus,
  Users,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import type {
  CSSProperties,
  HTMLAttributes,
  ReactNode,
  TableHTMLAttributes,
} from "react";
import { cn } from "@/lib/utils";
import { Badge } from "./badge";
import {
  WorkspaceDialogLayer,
  type WorkspaceDialogSize,
} from "./workspace-dialog";
import {
  WorkspaceAction,
  WorkspaceBadge,
  WorkspaceMetric,
  WorkspacePage,
  WorkspacePageHeader,
  WorkspacePanel,
  WorkspacePanelHeader,
  WorkspaceState,
  WorkspaceTable,
} from "./workspace";

type ChaRouteMeta = {
  eyebrow: string;
  title: string;
  description: string;
  icon: LucideIcon;
};

const exactRouteMeta: Record<string, ChaRouteMeta> = {
  "/cha": {
    eyebrow: "Customs operations",
    title: "CHA command centre",
    description:
      "Coordinate customs jobs, approvals, filing progress, customer advances, and operational exceptions.",
    icon: Gauge,
  },
  "/cha/approvals": {
    eyebrow: "Controlled decisions",
    title: "Checklist approvals",
    description:
      "Review checklist submissions and job-deletion requests without bypassing approval policy.",
    icon: CheckSquare,
  },
  "/cha/customers": {
    eyebrow: "Customer operations",
    title: "CHA customers",
    description:
      "Maintain customs customer profiles, account ownership, KYC records, and portal access.",
    icon: Users,
  },
  "/cha/customers/new": {
    eyebrow: "Customer onboarding",
    title: "New customer",
    description:
      "Create a customs customer profile with contact, finance, KYC, and portal settings.",
    icon: UserPlus,
  },
  "/cha/expenses": {
    eyebrow: "CHA finance",
    title: "CHA expenses",
    description:
      "Raise, review, approve, disburse, and reconcile job-linked operational expenses.",
    icon: CreditCard,
  },
  "/cha/jobs": {
    eyebrow: "Customs operations",
    title: "CHA jobs",
    description:
      "Search and coordinate every customs-clearance job across its controlled workflow.",
    icon: BriefcaseBusiness,
  },
  "/cha/reports": {
    eyebrow: "Operational intelligence",
    title: "CHA reports",
    description:
      "Review filing delays, financial exposure, completed-job reports, and the audit feed.",
    icon: BarChart3,
  },
  "/cha/settings": {
    eyebrow: "CHA administration",
    title: "CHA settings",
    description:
      "Manage numbering, access policy, job taxonomy, teams, and document requirements.",
    icon: Settings2,
  },
  "/cha/settings/filing-workflows": {
    eyebrow: "Workflow configuration",
    title: "Filing workflow builder",
    description:
      "Configure filing nodes, gates, role access, required evidence, and controlled transitions.",
    icon: Workflow,
  },
  "/expense": {
    eyebrow: "Expense operations",
    title: "Expense workspace",
    description:
      "Manage operational expense requests, approvals, payments, proofs, and reconciliation.",
    icon: CreditCard,
  },
};

function normalizePathname(pathname: string | null) {
  if (!pathname) return "/";
  const normalized = pathname.replace(/\/+$/, "");
  return normalized || "/";
}

export function getChaRouteMeta(pathname: string | null): ChaRouteMeta {
  const path = normalizePathname(pathname);
  const exact = exactRouteMeta[path];
  if (exact) return exact;

  if (/^\/cha\/customers\/[^/]+\/edit$/.test(path)) {
    return {
      eyebrow: "Customer administration",
      title: "Edit customer",
      description:
        "Update customer identity, ownership, KYC, financial policy, and portal access.",
      icon: Building2,
    };
  }

  if (/^\/cha\/jobs\/[^/]+$/.test(path)) {
    return {
      eyebrow: "Customs job workspace",
      title: "Job operations",
      description:
        "Coordinate documents, additional data, checklist decisions, filing, advances, expenses, and audit history.",
      icon: FileCog,
    };
  }

  return path.startsWith("/expense")
    ? exactRouteMeta["/expense"]
    : exactRouteMeta["/cha"];
}

export function ChaWorkspaceFrame({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const isFilingBuilder =
    normalizePathname(pathname) === "/cha/settings/filing-workflows";

  return (
    <WorkspacePage
      className={cn(
        "mnx-cha-page",
        isFilingBuilder && "mnx-cha-page-workflow-builder",
      )}
      data-cha-workspace="true"
    >
      <div className="mnx-cha-content">{children}</div>
    </WorkspacePage>
  );
}

export function ChaRoutePageHeader({
  actions,
  className,
  description,
  eyebrow,
  icon,
  title,
}: {
  actions?: ReactNode;
  className?: string;
  description?: ReactNode;
  eyebrow?: ReactNode;
  icon?: ReactNode;
  title?: ReactNode;
}) {
  const pathname = usePathname();
  const meta = getChaRouteMeta(pathname);
  const MetaIcon = meta.icon;

  return (
    <WorkspacePageHeader
      className={cn("mnx-cha-page-header", className)}
      eyebrow={typeof eyebrow === "string" ? eyebrow : meta.eyebrow}
      title={title ?? meta.title}
      description={description ?? meta.description}
      icon={icon ?? <MetaIcon aria-hidden="true" />}
      actions={actions}
    />
  );
}

export function ChaMetrics({
  className,
  ...props
}: HTMLAttributes<HTMLElement>) {
  return (
    <section
      className={cn("mnx-workspace-metrics mnx-cha-metrics", className)}
      {...props}
    />
  );
}

export function ChaMetric({
  detail,
  href,
  icon,
  label,
  value,
}: {
  detail?: ReactNode;
  href?: string;
  icon?: ReactNode;
  label: ReactNode;
  value: ReactNode;
}) {
  return (
    <WorkspaceMetric
      label={label}
      value={value}
      detail={detail}
      icon={icon}
      href={href}
    />
  );
}

export function ChaSection({
  actions,
  badge,
  children,
  className,
  description,
  eyebrow,
  title,
}: {
  actions?: ReactNode;
  badge?: ReactNode;
  children: ReactNode;
  className?: string;
  description?: ReactNode;
  eyebrow?: string;
  title: ReactNode;
}) {
  return (
    <WorkspacePanel className={cn("mnx-cha-section", className)}>
      <WorkspacePanelHeader
        className="mnx-cha-section-header"
        eyebrow={eyebrow}
        title={
          <span className="mnx-cha-section-title">
            {title}
            {badge ? <Badge variant="secondary">{badge}</Badge> : null}
          </span>
        }
        description={description}
        actions={actions}
      />
      <div className="mnx-cha-section-content">{children}</div>
    </WorkspacePanel>
  );
}

export function ChaPanel({
  className,
  ...props
}: HTMLAttributes<HTMLElement>) {
  return (
    <WorkspacePanel className={cn("mnx-cha-panel", className)} {...props} />
  );
}

export function ChaToolbar({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("mnx-cha-toolbar", className)} {...props} />;
}

export function ChaTabs({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("mnx-cha-tabs", className)}
      role="tablist"
      {...props}
    />
  );
}

export function ChaTable({
  className,
  ...props
}: TableHTMLAttributes<HTMLTableElement>) {
  return <WorkspaceTable className={cn("mnx-cha-table", className)} {...props} />;
}

export function ChaActionLink({
  children,
  className,
  href,
}: {
  children: ReactNode;
  className?: string;
  href: string;
}) {
  return (
    <Link className={cn("mnx-button mnx-button-secondary", className)} href={href}>
      {children}
    </Link>
  );
}

export const ChaAction = WorkspaceAction;
export const ChaStatus = WorkspaceBadge;

export function ChaDialogLayer({
  children,
  className,
  labelledBy,
  onClose,
  open,
  size = "default",
  style,
}: {
  children: ReactNode;
  className?: string;
  labelledBy?: string;
  onClose: () => void;
  open: boolean;
  size?: WorkspaceDialogSize;
  style?: CSSProperties;
}) {
  return (
    <WorkspaceDialogLayer
      className={cn("mnx-cha-dialog", className)}
      labelledBy={labelledBy}
      onClose={onClose}
      open={open}
      size={size}
      style={style}
    >
      {children}
    </WorkspaceDialogLayer>
  );
}

export function ChaLoadingState({
  description = "Loading customs operations data.",
}: {
  description?: string;
}) {
  return (
    <WorkspaceState
      variant="loading"
      eyebrow="Customs operations"
      title="Loading workspace"
      description={description}
      icon={<LoaderCircle className="mnx-state-spinner" aria-hidden="true" />}
    />
  );
}

export function ChaErrorState({
  description,
  onRetry,
}: {
  description: string;
  onRetry?: () => void;
}) {
  return (
    <WorkspaceState
      variant="danger"
      eyebrow="Customs operations"
      title="This workspace could not be loaded"
      description={description}
      icon={<AlertTriangle aria-hidden="true" />}
      action={
        onRetry ? <WorkspaceAction onClick={onRetry}>Try again</WorkspaceAction> : null
      }
    />
  );
}
