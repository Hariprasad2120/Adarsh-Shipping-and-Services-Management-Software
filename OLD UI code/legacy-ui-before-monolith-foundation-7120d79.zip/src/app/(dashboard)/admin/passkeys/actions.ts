"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/rbac";

async function requireAdmin() {
  const session = await auth();
  if (!session?.user) {
    throw new Error("Unauthorized");
  }
  await requirePermission(session.user.id, "admin.org.manage");
  return session;
}

const decisionSchema = z.object({
  requestId: z.string(),
  decision: z.enum(["APPROVED", "REJECTED"]),
});

export async function decidePasskeyResetAction(formData: FormData) {
  const session = await requireAdmin();
  const parsed = decisionSchema.parse({
    requestId: formData.get("requestId"),
    decision: formData.get("decision"),
  });

  const request = await db.passkeyResetRequest.update({
    where: { id: parsed.requestId },
    data: {
      status: parsed.decision,
      decidedAt: new Date(),
      decidedById: session.user.id,
    },
    include: { user: true },
  });

  if (parsed.decision === "APPROVED") {
    await db.user.update({
      where: { id: request.userId },
      data: { passkeySetupRequired: true },
    });
  }

  await db.securityEvent.create({
    data: {
      userId: request.userId,
      email: request.user.email,
      event: "PASSKEY_RESET_ADMIN_DECISION",
      outcome: parsed.decision,
      details: { requestId: request.id, actorId: session.user.id },
    },
  });

  revalidatePath("/admin/passkeys");
}

export async function forcePasskeyResetAction(formData: FormData) {
  const session = await requireAdmin();
  const userId = formData.get("userId");
  if (typeof userId !== "string" || !userId) throw new Error("Missing user");

  const user = await db.user.update({
    where: { id: userId },
    data: { passkeySetupRequired: true },
  });

  await db.passkeyResetRequest.create({
    data: {
      userId,
      status: "APPROVED",
      decidedAt: new Date(),
      decidedById: session.user.id,
      reason: "Forced by admin",
    },
  });

  await db.securityEvent.create({
    data: {
      userId,
      email: user.email,
      event: "PASSKEY_RESET_FORCED",
      outcome: "SUCCESS",
      details: { actorId: session.user.id },
    },
  });

  revalidatePath("/admin/passkeys");
}
