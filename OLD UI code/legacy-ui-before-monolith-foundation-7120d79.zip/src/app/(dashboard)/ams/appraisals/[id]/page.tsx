import { auth } from "@/lib/auth";
import { getNow } from "@/lib/clock";
import { db } from "@/lib/db";
import { BreadcrumbLabel } from "@/components/breadcrumb-label";
import { can, loadCaps, requirePermission } from "@/lib/rbac";
import { getRoles } from "@/modules/core/organisation/service";
import { getAppraisal, computeAppraisalScore, getSelfFormTemplate } from "@/modules/ams/service";
import { loadSelfCriteria, loadReviewerCriteria } from "@/modules/ams/criteria-cache";
import { listUsersSlim } from "@/modules/core/user/service";
import { notFound, redirect } from "next/navigation";
import { AppraisalDetail } from "./appraisal-detail";
import type { AppraisalSelfFormTemplate, SelfAssessmentAnswers } from "@/modules/ams/criteria-config";
import { filterCriteriaPointsByRole, mapCriterionRowToPoint } from "@/modules/ams/form-template";
import { resolveSelfFormTemplate } from "@/modules/ams/self-form-template";

type AppraisalDetailProps = React.ComponentProps<typeof AppraisalDetail>;

export default async function AppraisalDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) redirect("/login");

  const { id } = await params;
  const orgId = session.user.orgId!;
  const redirectContext = await db.appraisal.findUnique({
    where: { id },
    select: {
      stage: true,
      employee: { select: { id: true } },
      cycle: { select: { orgId: true } },
    },
  });

  if (!redirectContext || redirectContext.cycle.orgId !== orgId) notFound();
  if (redirectContext.stage === "DUE_NOTIFIED") {
    redirect(`/ams/appraisals/assign/${redirectContext.employee.id}`);
  }

  const [canAssign, canViewAll, canManageReview] = await Promise.all([
    can(session.user.id, "ams.appraisal.assign_reviewers"),
    can(session.user.id, "ams.appraisal.view_all"),
    can(session.user.id, "ams.appraisal.management_review"),
  ]);
  if (!canAssign && !canViewAll && !canManageReview) {
    await requirePermission(session.user.id, "ams.appraisal.assign_reviewers");
  }

  // All independent — run in parallel
  const [appraisal, roles, caps, now, selfRows, reviewerRows, selfTemplate] = await Promise.all([
    getAppraisal(id),
    getRoles(orgId),
    loadCaps(session.user.id),
    getNow(),
    loadSelfCriteria(orgId),      // cached — fast after first hit
    loadReviewerCriteria(orgId),  // cached — fast after first hit
    getSelfFormTemplate(orgId),
  ]);

  if (!appraisal) notFound();

  const selfCriteria = selfRows.filter((row) => row.kind === "CATEGORY").map(mapCriterionRowToPoint);
  const resolvedSelfTemplate = resolveSelfFormTemplate(selfCriteria, selfTemplate as AppraisalSelfFormTemplate);

  // Filter reviewer criteria by current user's role
  const myReviewer = appraisal.reviewers.find(
    (r) => r.userId === session.user.id && r.kind !== "MANAGEMENT"
  );
  const reviewerCriteria = myReviewer
    ? filterCriteriaPointsByRole(myReviewer.kind as "HR" | "TL" | "MANAGER" | "MANAGEMENT", reviewerRows)
    : reviewerRows.filter((row) => row.kind === "CATEGORY").map(mapCriterionRowToPoint);

  // Load score data for HIKE_FINALISATION only
  let scoreData: AppraisalDetailProps["scoreData"] = null;
  if (appraisal.stage === "HIKE_FINALISATION") {
    try {
      scoreData = await computeAppraisalScore(id);
    } catch {
      // score not available yet
    }
  }

  const hrRoleId = roles.find((r) => r.name === "HR")?.id;
  const tlRoleId = roles.find((r) => r.name === "TL")?.id;
  const managerRoleId = roles.find((r) => r.name === "Manager")?.id;

  // Use listUsersSlim — page only needs { id, name } for reviewer dropdowns
  const [hrUsers, tlUsers, managerUsers] = await Promise.all([
    hrRoleId ? listUsersSlim(orgId, { roleId: hrRoleId, active: true }) : [],
    tlRoleId ? listUsersSlim(orgId, { roleId: tlRoleId, active: true }) : [],
    managerRoleId ? listUsersSlim(orgId, { roleId: managerRoleId, active: true }) : [],
  ]);
  const safeAppraisal: AppraisalDetailProps["appraisal"] = {
    ...appraisal,
    dueDate: appraisal.dueDate.toISOString(),
    availabilityDeadline: appraisal.availabilityDeadline?.toISOString() ?? null,
    selfAssessmentDeadline: appraisal.selfAssessmentDeadline?.toISOString() ?? null,
    reviewerRatingDeadline: appraisal.reviewerRatingDeadline?.toISOString() ?? null,
    selfAssessment: appraisal.selfAssessment
      ? {
          answers: appraisal.selfAssessment.answers as SelfAssessmentAnswers,
          submittedAt: appraisal.selfAssessment.submittedAt?.toISOString() ?? appraisal.updatedAt.toISOString(),
          editCount: (appraisal.selfAssessment as { editCount?: number }).editCount ?? 0,
        }
      : null,
    reviewerRatings: appraisal.reviewerRatings.map((row) => ({
      id: row.id,
      ratings: row.ratings as AppraisalDetailProps["appraisal"]["reviewerRatings"][number]["ratings"],
      status: row.status,
      submittedAt: row.submittedAt?.toISOString() ?? null,
      updatedAt: row.updatedAt.toISOString(),
      reviewer: {
        kind: row.reviewer.kind,
        user: { name: row.reviewer.user.name },
      },
    })),
    managementReviews: appraisal.managementReviews.map((row) => ({
      id: row.id,
      ratings: row.ratings as AppraisalDetailProps["appraisal"]["managementReviews"][number]["ratings"],
      proposedDates: row.proposedDates.map((date) => date.toISOString()),
      reviewer: { name: row.reviewer.name },
    })),
    reviewers: appraisal.reviewers.map((reviewer) => ({
      ...reviewer,
      assignedAt: reviewer.assignedAt.toISOString(),
      submissionStatus: reviewer.ratings[0]?.status ?? null,
      submittedAt: reviewer.ratings[0]?.submittedAt?.toISOString() ?? null,
    })),
    meeting: appraisal.meeting
      ? {
          ...appraisal.meeting,
          scheduledAt: appraisal.meeting.scheduledAt.toISOString(),
          minutes: appraisal.meeting.minutes.map((minute) => ({
            ...minute,
            createdAt: minute.createdAt.toISOString(),
            updatedAt: minute.updatedAt.toISOString(),
          })),
        }
      : null,
    hikeDecision: appraisal.hikeDecision
      ? {
          ...appraisal.hikeDecision,
          effectiveFrom: appraisal.hikeDecision.effectiveFrom.toISOString(),
        }
      : null,
    auditLog: appraisal.auditLog.map((entry) => ({
      ...entry,
      createdAt: entry.createdAt.toISOString(),
    })),
  };

  return (
    <div className="space-y-6">
      <BreadcrumbLabel segment={id} label={appraisal.employee.name} />
      <AppraisalDetail
        appraisal={safeAppraisal}
        hrUsers={hrUsers as AppraisalDetailProps["hrUsers"]}
        tlUsers={tlUsers as AppraisalDetailProps["tlUsers"]}
        managerUsers={managerUsers as AppraisalDetailProps["managerUsers"]}
        caps={caps}
        currentUserId={session.user.id}
        serverNow={now.toISOString()}
        selfCriteria={selfCriteria}
        selfTemplate={resolvedSelfTemplate}
        reviewerCriteria={reviewerCriteria}
        scoreData={scoreData}
      />
    </div>
  );
}
