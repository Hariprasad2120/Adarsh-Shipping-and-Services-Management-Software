import { auth } from "@/lib/auth";
import { loadCaps } from "@/lib/rbac";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import { OtClient } from "./ot-client";
import { Clock } from "lucide-react";
import { getOTEntries } from "@/modules/attendance/service";
import { getNow } from "@/lib/clock";
import { ensureAttendanceConfiguration } from "@/lib/ot";

export const metadata = {
  title: "Overtime Management | Attendance | Adarsh Shipping",
};

interface PageProps {
  searchParams?: Promise<{ month?: string }> | { month?: string };
}

type OtClientProps = React.ComponentProps<typeof OtClient>;

function toIsoString(value: Date | string | null | undefined) {
  if (!value) return null;
  return value instanceof Date ? value.toISOString() : value;
}

export default async function OvertimePage({ searchParams }: PageProps) {
  const session = await auth();
  if (!session) redirect("/login");

  const caps = await loadCaps(session.user.id);
  const canApprove = Boolean(caps["attendance.ot.approve"] || caps["attendance.punch.manage"]);
  const canRequest = Boolean(caps["attendance.ot.request"]);

  if (!canApprove && !canRequest) {
    return (
      <div className="rounded-xl border border-mono-border bg-mono-card p-8 text-center text-sm text-mono-muted">
        Access Denied: You do not have permissions for Overtime Management.
      </div>
    );
  }

  const orgId = session.user.orgId;
  if (!orgId) {
    return (
      <div className="rounded-xl border border-mono-border bg-mono-card p-8 text-center text-sm text-mono-muted">
        Organisation configuration missing.
      </div>
    );
  }

  // Resolve searchParams month
  const resolvedParams = await (searchParams instanceof Promise ? searchParams : Promise.resolve(searchParams));
  const nowIst = await getNow();
  const defaultMonth = `${nowIst.getUTCFullYear()}-${String(nowIst.getUTCMonth() + 1).padStart(2, "0")}`;
  const monthStr = resolvedParams?.month || defaultMonth;
  const [yearStr, monthPartStr] = monthStr.split("-");
  const currentYear = parseInt(yearStr!, 10) || nowIst.getUTCFullYear();
  const currentMonth = parseInt(monthPartStr!, 10) || (nowIst.getUTCMonth() + 1);

  const startOfMonth = new Date(currentYear, currentMonth - 1, 1);
  const endOfMonth = new Date(currentYear, currentMonth, 0);

  // Load basic entries for legacy requesting users
  const legacyEntries = !canApprove
    ? await getOTEntries(orgId, { userId: session.user.id })
    : [];

  // If user is admin/manager, load all admin data
  let adminData = null;
  if (canApprove) {
    await ensureAttendanceConfiguration(orgId);
    // Parallelize all independent admin queries; derive totalLopDays from lopRecordsDb to avoid double fetch
    const [approvedOt, pendingCount, otRecords, holidays, lopRecordsDb, otSettings, workingCalendar, shifts, employees, branches] = await Promise.all([
      db.otRecord.findMany({
        where: {
          user: { orgId },
          date: { gte: startOfMonth, lte: endOfMonth },
          approvalStatus: "APPROVED",
        },
        select: {
          otHours: true,
          otAmount: true,
          compOffDays: true,
        },
      }),
      db.otRecord.count({
        where: {
          user: { orgId },
          date: { gte: startOfMonth, lte: endOfMonth },
          approvalStatus: { in: ["PENDING", "PENDING_MANAGER"] },
        },
      }),
      db.otRecord.findMany({
        where: {
          user: { orgId },
          date: { gte: startOfMonth, lte: endOfMonth },
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              employeeNumber: true,
              department: { select: { name: true } },
              employmentRecord: { select: { ctc: true } },
            },
          },
          shift: {
            select: {
              id: true,
              name: true,
              startTime: true,
              endTime: true,
            },
          },
        },
        orderBy: [
          { user: { name: "asc" } },
          { date: "asc" },
        ],
      }),
      db.holiday.findMany({
        where: {
          orgId,
          date: {
            gte: new Date(currentYear, 0, 1),
            lte: new Date(currentYear, 11, 31),
          },
        },
        include: {
          branch: { select: { name: true } },
        },
        orderBy: { date: "asc" },
      }),
      db.employeeLop.findMany({
        where: {
          user: { orgId },
          payrollMonth: startOfMonth,
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              employeeNumber: true,
              department: { select: { name: true } },
            },
          },
        },
        orderBy: { user: { name: "asc" } },
      }),
      db.otSettings.findUnique({
        where: { orgId },
      }),
      db.workingCalendar.findUnique({
        where: { orgId },
      }),
      db.shift.findMany({
        where: { orgId },
        orderBy: [{ isDefault: "desc" }, { startTime: "asc" }, { name: "asc" }],
      }),
      db.user.findMany({
        where: { orgId, active: true, isPlatformAdmin: false },
        select: {
          id: true,
          name: true,
          employeeNumber: true,
          department: { select: { name: true } },
          employmentRecord: { select: { ctc: true } },
          hrmsShiftAssignments: {
            where: {
              OR: [{ endDate: null }, { endDate: { gte: startOfMonth } }],
            },
            orderBy: { startDate: "desc" },
            take: 1,
            include: {
              shift: {
                select: {
                  id: true,
                  name: true,
                  startTime: true,
                  endTime: true,
                },
              },
            },
          },
        },
        orderBy: { name: "asc" },
      }),
      db.branch.findMany({
        where: { orgId },
        select: { id: true, name: true },
        orderBy: { name: "asc" },
      }),
    ]);

    const totalOtHours = approvedOt.reduce((acc, r) => acc + r.otHours, 0);
    const totalOtAmount = approvedOt.reduce((acc, r) => acc + r.otAmount, 0);
    const totalCompOffDays = approvedOt.reduce((acc, r) => acc + r.compOffDays, 0);
    const totalLopDays = lopRecordsDb.reduce((acc, r) => acc + r.lopDays, 0);

    const settings = otSettings || {
      id: "global",
      orgId,
      standardHours: 8.0,
      otRate: 1.5,
      graceMinutes: 15,
      compOffSlabs: [
        { minHours: 4, compOffDays: 0.5 },
        { minHours: 8, compOffDays: 1.0 },
        { minHours: 11, compOffDays: 1.5 },
      ],
    };

    adminData = {
      stats: {
        totalOtHours,
        totalOtAmount,
        totalCompOffDays,
        totalLopDays,
        pendingCount,
      },
      otRecords: otRecords.map((record) => ({
        ...record,
        date: record.date.toISOString(),
        firstPunchAt: toIsoString(record.firstPunchAt),
        lastPunchAt: toIsoString(record.lastPunchAt),
        user: {
          ...record.user,
        },
      })),
      holidays: holidays.map((holiday) => ({
        ...holiday,
        date: holiday.date.toISOString(),
      })),
      lopRecords: lopRecordsDb,
      settings,
      employees: employees.map((employee) => ({
        ...employee,
        hrmsShiftAssignments: employee.hrmsShiftAssignments.map((assignment) => ({
          ...assignment,
          startDate: assignment.startDate.toISOString(),
          endDate: toIsoString(assignment.endDate),
        })),
      })),
      branches,
      workingCalendar,
      shifts,
    };
  }

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <p className="text-sm font-medium text-mono-muted">
          {canApprove
            ? "Configure grace periods, view overtime metrics, track holidays, manage LOP logs, and export payroll statements."
            : "Request overtime compensation and track your submission history."}
        </p>
      </div>

      <OtClient
        initialEntries={legacyEntries as OtClientProps["initialEntries"]}
        canApprove={canApprove}
        canRequest={canRequest}
        currentUserId={session.user.id}
        monthStr={monthStr}
        adminData={adminData as OtClientProps["adminData"]}
      />
    </div>
  );
}
