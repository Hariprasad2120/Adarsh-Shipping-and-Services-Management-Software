import { redirect } from "next/navigation";
import { Lock } from "lucide-react";
import { auth } from "@/lib/auth";
import { can } from "@/lib/rbac";
import { WorkspaceState } from "@/components/monolith";
import DesignSystemClient from "./design-system-client";

export default async function AdminDesignSystemPage() {
  const session = await auth();
  if (!session) redirect("/login");

  const allowed = await can(session.user.id, "admin.org.manage");
  if (!allowed) {
    return (
      <WorkspaceState
        variant="permission"
        eyebrow="Permission required"
        title="Design system"
        description="You need administrator access to view the Monolith design-system showcase."
        icon={<Lock size={22} />}
      />
    );
  }

  return <DesignSystemClient />;
}
