"use client";

import { LogOut } from "lucide-react";
import { Button } from "@/components/monolith/button";
import { performLogout } from "@/lib/logout";

export function RootSignOutButton() {
  return (
    <Button
      variant="outline"
      size="lg"
      onClick={() => void performLogout()}
      className="uppercase tracking-[0.12em]"
    >
      <LogOut className="mr-2 size-4 text-[#F9D972]" />
      Sign Out
    </Button>
  );
}
