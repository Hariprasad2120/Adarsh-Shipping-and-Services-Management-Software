"use client";

import type { CSSProperties } from "react";
import { useEffect, useState } from "react";

export function MainShell({ children }: { children: React.ReactNode }) {
  const [pl, setPl] = useState("14.375rem");

  useEffect(() => {
    document.documentElement.setAttribute("data-dashboard-shell", "true");

    const update = () => {
      const collapsed =
        document.documentElement.getAttribute("data-sidebar-collapsed") === "true";
      setPl(collapsed ? "3.5rem" : "14.375rem");
    };
    update();
    const observer = new MutationObserver(update);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-sidebar-collapsed"],
    });
    return () => {
      observer.disconnect();
      document.documentElement.removeAttribute("data-dashboard-shell");
    };
  }, []);

  return (
    <main
      data-main-shell-scroll="true"
      className="flex min-w-0 flex-1 flex-col overflow-y-auto overflow-x-hidden bg-mono-page pl-0 transition-[padding-left] duration-300 lg:pl-[var(--sidebar-width)]"
      style={{ ["--sidebar-width" as string]: pl } as CSSProperties}
    >
      {children}
    </main>
  );
}
